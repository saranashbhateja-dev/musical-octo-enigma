/* Apex OS optional account controls. App access is never gated by authentication. */
(() => {
  'use strict';
  const form = document.getElementById('auth-form');
  if (!form) return;
  const emailInput = document.getElementById('auth-email');
  const passwordInput = document.getElementById('auth-password');
  const submit = document.getElementById('auth-submit');
  const message = document.getElementById('auth-message');
  const forgot = document.getElementById('auth-forgot');
  const tabs = [...document.querySelectorAll('[data-auth-mode]')];
  const config = window.APEX_SUPABASE_CONFIG || {};
  const status = document.getElementById('settings-account-status');
  const statusCopy = document.getElementById('settings-account-copy');
  const label = document.getElementById('account-label');
  const emailLabel = document.getElementById('account-email-label');
  const avatar = document.getElementById('account-avatar');
  const signout = document.getElementById('account-signout');
  let mode = 'signin';
  let client = null;
  let currentUser = null;

  function showMessage(text, kind = '') {
    message.textContent = text;
    message.className = `auth-message visible${kind ? ` ${kind}` : ''}`;
  }
  function setMode(next) {
    mode = next;
    tabs.forEach(tab => tab.classList.toggle('active', tab.dataset.authMode === next));
    submit.textContent = next === 'signup' ? 'Create account →' : 'Sign in →';
    passwordInput.autocomplete = next === 'signup' ? 'new-password' : 'current-password';
    forgot.hidden = next === 'signup';
    message.className = 'auth-message';
  }
  function renderUser(user) {
    currentUser = user || null;
    const email = user?.email || '';
    if (status) status.textContent = user ? `Signed in${email ? ` as ${email}` : ''}` : 'Not signed in';
    if (statusCopy) statusCopy.textContent = user ? 'Your Supabase Auth session is active on this device.' : 'You are using Apex OS locally on this device. Sign-in is optional.';
    if (label) label.textContent = user ? (email.split('@')[0] || 'APEX ACCOUNT').toUpperCase() : 'APEX WORKSPACE';
    if (emailLabel) emailLabel.textContent = user ? email : 'Local-first · Private';
    if (avatar) avatar.textContent = (email[0] || 'A').toUpperCase();
    if (signout) signout.hidden = !user;
    form.hidden = !!user;
    const tabsWrap = document.querySelector('.settings-auth-tabs');
    if (tabsWrap) tabsWrap.hidden = !!user;
    if (forgot) forgot.hidden = !!user || mode === 'signup';
  }
  tabs.forEach(tab => tab.addEventListener('click', () => setMode(tab.dataset.authMode)));
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!client) { showMessage('Account service is unavailable. Check your internet connection and Supabase configuration. Apex OS remains usable without signing in.', 'error'); return; }
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    submit.disabled = true;
    submit.textContent = mode === 'signup' ? 'Creating account…' : 'Signing in…';
    message.className = 'auth-message';
    try {
      if (mode === 'signup') {
        const { data, error } = await client.auth.signUp({ email, password });
        if (error) throw error;
        if (data.session) { renderUser(data.user); showMessage('Account created and signed in.', 'success'); }
        else showMessage('Account created. Check your email for the confirmation link, then sign in here.', 'success');
      } else {
        const { data, error } = await client.auth.signInWithPassword({ email, password });
        if (error) throw error;
        renderUser(data.user);
        showMessage('Signed in successfully.', 'success');
      }
    } catch (error) { showMessage(error?.message || 'Authentication failed. Please try again.', 'error'); }
    finally { submit.disabled = false; submit.textContent = mode === 'signup' ? 'Create account →' : 'Sign in →'; }
  });
  forgot.addEventListener('click', async () => {
    if (!client) { showMessage('Account service is unavailable. Apex OS remains usable without signing in.', 'error'); return; }
    const email = emailInput.value.trim();
    if (!email) { showMessage('Enter your email address first, then choose Forgot password.', 'error'); emailInput.focus(); return; }
    try {
      const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo: window.location.href.split('#')[0] });
      if (error) throw error;
      showMessage('If an account exists for that email, a password-reset link has been sent.', 'success');
    } catch (error) { showMessage(error?.message || 'Could not send the reset email.', 'error'); }
  });
  async function doSignOut() {
    if (!client || !currentUser) return;
    try {
      const { error } = await client.auth.signOut();
      if (error) throw error;
      renderUser(null);
      showMessage('Signed out. Apex OS remains open in local mode.', 'success');
    } catch (error) { showMessage(error?.message || 'Could not sign out.', 'error'); }
  }
  signout?.addEventListener('click', doSignOut);
  if (window.supabase?.createClient && config.url && config.publishableKey) {
    client = window.supabase.createClient(config.url, config.publishableKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
    client.auth.getSession().then(({ data, error }) => { if (!error) renderUser(data?.session?.user || null); }).catch(() => renderUser(null));
    client.auth.onAuthStateChange((event, session) => { if (event === 'SIGNED_IN' || event === 'INITIAL_SESSION' || event === 'TOKEN_REFRESHED') renderUser(session?.user || null); if (event === 'SIGNED_OUT') renderUser(null); });
  } else {
    renderUser(null);
    showMessage('Supabase Auth is not configured or unavailable. The app is still fully accessible locally.', '');
  }
})();
