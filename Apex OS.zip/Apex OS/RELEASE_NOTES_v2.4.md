# Apex OS v2.4 — Optional account controls in Settings

- Removed the full-screen login gate. Apex OS opens directly to the dashboard.
- Moved sign-in, account creation, password reset, and sign-out into Settings → Account & Security.
- Supabase Auth is optional for app access; unavailable auth does not block local use.
- Preserved the existing separate device-pairing sync controls.
- Clarification: authentication does not currently isolate shared sync data by account.
